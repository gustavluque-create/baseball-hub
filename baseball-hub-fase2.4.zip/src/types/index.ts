export type CompetitionType = 'league' | 'tournament' | 'cup';
export type CompetitionStatus = 'active' | 'upcoming' | 'archived';

export interface Competition {
  id: string;
  name: string;
  shortName: string;
  country: string;
  type: CompetitionType;
  logo: string;
  status: CompetitionStatus;
  currentSeasonId: string;
}

export interface Season {
  id: string;
  competitionId: string;
  year: number;
  name: string;
  startDate: string;
  endDate?: string;
  isCurrent: boolean;
  status: 'scheduled' | 'in_progress' | 'finished';
}

export interface TeamColors {
  primary: string;
  secondary: string;
  text: string;
}

export interface Team {
  id: string;
  name: string;
  nickname: string;
  shortName: string;
  city: string;
  stadium: string;
  capacity?: number;
  stadiumCapacity?: number;
  manager: string;
  foundedYear: number;
  championships: number | string[];
  colors: TeamColors;
  primaryColor?: string;
  logo: string;
  competitionId: string;
  seasonId: string;
  record: {
    wins: number;
    losses: number;
    pct: number;
    streak: string;
    lastTen: string;
    position: number;
  };
}

export type PlayerPosition = 'C' | '1B' | '2B' | '3B' | 'SS' | 'LF' | 'CF' | 'RF' | 'DH' | 'SP' | 'RP' | 'P';
export type BatHand = 'R' | 'L' | 'S';
export type ThrowHand = 'R' | 'L';

export interface Player {
  id: string;
  firstName: string;
  lastName: string;
  fullName: string;
  slug: string;
  teamId: string;
  teamName: string;
  teamShort: string;
  position: PlayerPosition;
  jerseyNumber: number;
  number?: number;
  shortName?: string;
  birthDate: string;
  age: number;
  birthPlace: string;
  birthCountry: string;
  height: string; // e.g. "1.85 m" or "6'1\""
  weight: string; // e.g. "88 kg" or "195 lbs"
  bats: BatHand;
  throws: ThrowHand;
  photo: string;
  bio: string;
  status: 'active' | 'injured' | 'minors';
  isFavorite?: boolean;
  isHallOfFame?: boolean;
  isAllStar?: boolean;
  war?: number;
}

export interface CareerBattingTotals {
  seasons: number;
  games: number;
  pa: number;
  ab: number;
  r: number;
  h: number;
  doubles: number;
  triples: number;
  hr: number;
  rbi: number;
  bb: number;
  so: number;
  sb: number;
  avg: number;
  obp: number;
  slg: number;
  ops: number;
  war: number;
}

export interface CareerPitchingTotals {
  seasons: number;
  games: number;
  gs: number;
  w: number;
  l: number;
  sv: number;
  ip: number;
  h: number;
  r: number;
  er: number;
  bb: number;
  so: number;
  hr: number;
  era: number;
  whip: number;
  war: number;
}

export interface PlayerCareerTotals {
  batting?: CareerBattingTotals;
  pitching?: CareerPitchingTotals;
  regularBatting?: CareerBattingTotals;
  postseasonBatting?: CareerBattingTotals;
  regularPitching?: CareerPitchingTotals;
  postseasonPitching?: CareerPitchingTotals;
}

export interface PlayerGameLogItem {
  id: string;
  gameId: string;
  gameNumber: number; // 1 to 10
  date: string;
  formattedDate: string;
  opponentId: string;
  opponentShort: string;
  opponentName: string;
  opponentLogo?: string;
  isHome: boolean;
  score: string;
  teamScore: number;
  opponentScore: number;
  result: 'W' | 'L';

  // Batting stats for this game (position player/batter)
  ab?: number;
  r?: number;
  h?: number;
  doubles?: number;
  triples?: number;
  hr?: number;
  rbi?: number;
  bb?: number;
  so?: number;
  sb?: number;
  gameAvg?: number; // hits in this game / ab (e.g. 0.500)
  rollingAvg?: number; // progressive season/recent average (e.g. 0.355)
  rollingOps?: number;

  // Pitching stats for this appearance (pitcher)
  decision?: 'W' | 'L' | 'S' | 'H' | 'ND';
  ip?: string; // e.g. "6.2"
  ipDecimal?: number; // e.g. 6.67
  hAllowed?: number;
  rAllowed?: number;
  er?: number;
  bbPitcher?: number;
  soPitcher?: number;
  hrAllowed?: number;
  gameEra?: number; // ERA in this specific outing
  rollingEra?: number; // progressive season/recent ERA (e.g. 2.45)
  rollingWhip?: number;
}

export interface PlayerDetailResponse {
  player: Player;
  batting?: BattingStats;
  pitching?: PitchingStats;
  careerBatting?: BattingStats[];
  careerPitching?: PitchingStats[];
  careerTotals?: PlayerCareerTotals;
  recentGames?: PlayerGameLogItem[];
}

export type GameStatus = 'SCHEDULED' | 'LIVE' | 'FINAL' | 'POSTPONED' | 'SUSPENDED' | 'CANCELLED';

export interface InningScore {
  inning: number;
  home: number | null;
  away: number | null;
}

export interface BatterBox {
  playerId: string;
  name: string;
  position: string;
  order: number;
  ab: number;
  r: number;
  h: number;
  rbi: number;
  bb: number;
  so: number;
  avg: string;
  ops: string;
}

export interface PitcherBox {
  playerId: string;
  name: string;
  decision?: 'W' | 'L' | 'S' | 'H';
  ip: string;
  h: number;
  r: number;
  er: number;
  bb: number;
  so: number;
  hr: number;
  era: string;
}

export interface LineupPlayer {
  order: number; // 1 to 9
  playerId: string;
  name: string;
  jerseyNumber?: number;
  position: string; // 'DH' | '1B' | '2B' | '3B' | 'SS' | 'LF' | 'CF' | 'RF' | 'C' | 'P'
  bats?: BatHand;
  throws?: ThrowHand;
  ab?: number;
  r?: number;
  h?: number;
  rbi?: number;
  bb?: number;
  so?: number;
  avg?: string;
  notes?: string;
}

export interface TeamLineup {
  startingPitcher?: {
    playerId?: string;
    name: string;
    jerseyNumber?: number;
    throws?: ThrowHand;
    era?: string;
    ip?: string;
    h?: number;
    r?: number;
    er?: number;
    bb?: number;
    so?: number;
    pitches?: number;
  };
  battingOrder: LineupPlayer[];
  bench?: {
    playerId: string;
    name: string;
    position: string;
    jerseyNumber?: number;
  }[];
}

export interface GameLineups {
  away: TeamLineup | any;
  home: TeamLineup | any;
  pitchers?: any;
  boxScore?: any;
}

export interface PlayEvent {
  id: string;
  inning: number;
  isTop: boolean;
  outs: number;
  description: string;
  scoreAfter: string;
  isScoringPlay?: boolean;
  playType?: string;
  batterName?: string;
  pitcherName?: string;
  runsScored?: number;
  rbiCount?: number;
  timestamp?: string;
}

export interface Game {
  id: string;
  competitionId: string;
  seasonId: string;
  date: string;
  time: string;
  stadium: string;
  status: GameStatus;
  homeTeam: Team;
  awayTeam: Team;
  homeScore: number;
  awayScore: number;
  currentInning?: number;
  isTopInning?: boolean;
  outs?: number;
  balls?: number;
  strikes?: number;
  bases?: {
    first: boolean;
    second: boolean;
    third: boolean;
  };
  lineScore: InningScore[];
  homeHits: number;
  awayHits: number;
  homeErrors: number;
  awayErrors: number;
  umpires?: string[];
  winningPitcher?: { name: string; record: string };
  losingPitcher?: { name: string; record: string };
  savePitcher?: { name: string; saves: number };
  battingBoxScore?: {
    home: BatterBox[];
    away: BatterBox[];
  };
  pitchingBoxScore?: {
    home: PitcherBox[];
    away: PitcherBox[];
  };
  plays?: PlayEvent[];
  lineups?: GameLineups;
}

export interface BattingStats {
  id: string;
  playerId: string;
  playerName: string;
  teamId: string;
  teamShort: string;
  position: PlayerPosition;
  seasonYear: number;
  seasonId?: string;
  stage?: 'regular' | 'postseason';
  games: number;
  pa: number;
  ab: number;
  r: number;
  h: number;
  doubles: number;
  triples: number;
  hr: number;
  rbi: number;
  bb: number;
  so: number;
  sb: number;
  cs: number;
  avg: number;
  obp: number;
  slg: number;
  ops: number;
  // Sabermetrics
  woba?: number;
  war?: number;
  babip?: number;
  iso?: number;
  opsPlus?: number;
}

export interface PitchingStats {
  id: string;
  playerId: string;
  playerName: string;
  teamId: string;
  teamShort: string;
  position: 'SP' | 'RP';
  seasonYear: number;
  seasonId?: string;
  stage?: 'regular' | 'postseason';
  games: number;
  gs: number;
  cg: number;
  sho: number;
  w: number;
  l: number;
  sv: number;
  wins?: number;
  losses?: number;
  saves?: number;
  ip: number;
  h: number;
  r: number;
  er: number;
  bb: number;
  so: number;
  hr: number;
  era: number;
  whip: number;
  fip?: number;
  eraPlus?: number;
  k9?: number;
  bb9?: number;
  war?: number;
}

export interface FieldingStats {
  id: string;
  playerId: string;
  playerName: string;
  teamId: string;
  teamShort: string;
  position: PlayerPosition;
  games: number;
  po: number;
  a: number;
  e: number;
  dp: number;
  fpct: number;
}

export interface Standing {
  id?: string;
  competitionId?: string;
  seasonId?: string;
  teamId: string;
  teamName: string;
  teamShort: string;
  logo: string;
  teamLogo?: string;
  rank?: number;
  position?: number;
  division: string;
  gamesPlayed: number;
  games?: number;
  wins: number;
  losses: number;
  pct: number;
  diff: number | string; // GB (e.g. 0, 2.5 or '—')
  gamesBehind?: number;
  runsScored: number;
  runsAllowed: number;
  runsAgainst?: number;
  runDiff: number;
  runDifferential?: number;
  homeRecord: string;
  awayRecord: string;
  lastTen: string;
  streak: string;
}

export interface NewsArticle {
  id: string;
  title: string;
  slug: string;
  subtitle?: string;
  excerpt: string;
  content: string;
  image: string;
  author: string;
  publishedAt: string;
  readingTimeMinutes?: number;
  category: 'Crónica' | 'Entrevista' | 'Estadísticas' | 'Ligas Extranjeras' | 'Récords' | string;
  tags: string[];
  competitionId?: string;
  teamId?: string;
  playerId?: string;
  relatedTeams?: string[];
  relatedPlayers?: string[];
  isFeatured?: boolean;
  imageHeight?: 'tall' | 'medium' | 'wide' | 'panoramic';
}

export interface VideoItem {
  id: string;
  title: string;
  thumbnail: string;
  duration: string;
  competition: string;
  category?: string;
  views: string;
  viewsCount?: number;
  date: string;
  publishedAt?: string;
  url?: string;
}

export interface IngestionValidationSummary {
  totalRecords: number;
  validRecords: number;
  warnings: Array<{ row: number; field: string; message: string }>;
  errors: Array<{ row: number; field: string; message: string }>;
  preview: any[];
  records?: any[];
}

export interface TeamAggregatedStats {
  teamId: string;
  teamShort: string;
  teamName: string;
  batting: {
    avg: number;
    obp: number;
    slg: number;
    ops: number;
    runs: number;
    hits: number;
    doubles: number;
    triples: number;
    homeRuns: number;
    rbi: number;
    walks: number;
    strikeouts: number;
    stolenBases: number;
  };
  pitching: {
    era: number;
    whip: number;
    wins: number;
    losses: number;
    saves: number;
    inningsPitched: number;
    hitsAllowed: number;
    runsAllowed: number;
    earnedRuns: number;
    walks: number;
    strikeouts: number;
    homeRunsAllowed: number;
    k9: number;
    bb9: number;
  };
}

export interface MatchupComparisonData {
  game: Game;
  awayTeam: Team;
  homeTeam: Team;
  awayStanding?: Standing;
  homeStanding?: Standing;
  awayStats: TeamAggregatedStats;
  homeStats: TeamAggregatedStats;
  headToHeadGames: Game[];
  awayTopBatter?: { player: Player; stats: BattingStats };
  homeTopBatter?: { player: Player; stats: BattingStats };
  awayTopPitcher?: { player: Player; stats: PitchingStats };
  homeTopPitcher?: { player: Player; stats: PitchingStats };
}

export interface TeamDirectComparisonData {
  teamA: Team;
  teamB: Team;
  standingA?: Standing;
  standingB?: Standing;
  statsA: TeamAggregatedStats;
  statsB: TeamAggregatedStats;
  headToHeadGames: Game[];
  headToHeadSummary: {
    totalGames: number;
    teamAWins: number;
    teamBWins: number;
    teamARuns: number;
    teamBRuns: number;
  };
  topBatterA?: { player: Player; stats: BattingStats };
  topBatterB?: { player: Player; stats: BattingStats };
  topPitcherA?: { player: Player; stats: PitchingStats };
  topPitcherB?: { player: Player; stats: PitchingStats };
}

export interface ScoreNotificationEvent {
  id: string;
  gameId: string;
  timestamp: number;
  homeTeam: Team;
  awayTeam: Team;
  scoringTeam: Team;
  scoringTeamSide: 'home' | 'away';
  runsScored: number;
  homeScore: number;
  awayScore: number;
  inning: number;
  isTopInning: boolean;
  outs: number;
  title?: string;
  description: string;
  playType?: 'homerun' | 'hit' | 'sacrifice' | 'walk' | 'standard';
  autoDismissMs?: number;
  read?: boolean;
}

export type RealTimeConnectionMode = 'stream' | 'polling';
export type RealTimeConnectionStatus = 'connected' | 'polling' | 'connecting' | 'disconnected' | 'error';

export interface AdminUser {
  id: string;
  username: string;
  name: string;
  email: string;
  role: 'superadmin' | 'admin' | 'anotador' | 'prensa' | 'official_scorer' | 'editor';
  lastLogin: string;
}

export interface AdminAuthResponse {
  success: boolean;
  token?: string;
  admin?: AdminUser;
  message?: string;
}

export interface AdminAuditLog {
  id: string;
  timestamp: number;
  username: string;
  action: string;
  details: string;
  category: 'auth' | 'games' | 'players' | 'teams' | 'etl' | 'system';
}

export interface AdminSystemOverview {
  totalGames: number;
  liveGames: number;
  totalPlayers: number;
  totalTeams: number;
  notificationClients: number;
  uptimeSeconds: number;
  lastIngestionDate?: string;
}

export interface ArticleComment {
  id: string;
  articleSlug: string;
  authorName: string;
  favoriteTeam?: string;
  content: string;
  createdAt: string;
  likes?: number;
}

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export interface DatabaseApiLogEntry {
  id: string;
  timestamp: string;
  epochMs: number;
  method: HttpMethod;
  endpoint: string;
  isWriteOperation: boolean;
  status?: number;
  statusText?: string;
  durationMs: number;
  success: boolean;
  requestPayload?: any;
  responsePreview?: any;
  error?: {
    message: string;
    code?: string | number;
    details?: any;
  };
  context?: string;
}

