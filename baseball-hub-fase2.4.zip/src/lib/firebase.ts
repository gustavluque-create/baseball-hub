import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export const app = initializeApp(firebaseConfig);
export const firebaseApp = app;
export { firebaseConfig };
export const auth = getAuth(app);
export const googleAuthProvider = new GoogleAuthProvider();
