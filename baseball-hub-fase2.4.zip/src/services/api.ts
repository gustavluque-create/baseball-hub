import {
  Competition,
  Season,
  Team,
  Player,
  PlayerDetailResponse,
  PlayerGameLogItem,
  Game,
  BattingStats,
  PitchingStats,
  Standing,
  NewsArticle,
  VideoItem,
  IngestionValidationSummary,
  MatchupComparisonData,
  TeamDirectComparisonData,
  ScoreNotificationEvent,
  AdminUser,
  AdminAuthResponse,
  AdminAuditLog,
  AdminSystemOverview,
  ArticleComment,
  DatabaseApiLogEntry,
  HttpMethod,
} from '../types/index.ts';
import { clientPersistence } from './clientPersistence.ts';

const API_BASE = '/api';

export class DatabaseApiError extends Error {
  public status: number;
  public statusText: string;
  public method: HttpMethod;
  public endpoint: string;
  public details?: any;
  public payload?: any;

  constructor(
    message: string,
    status: number,
    statusText: string,
    method: HttpMethod,
    endpoint: string,
    details?: any,
    payload?: any
  ) {
    super(message);
    this.name = 'DatabaseApiError';
    this.status = status;
    this.statusText = statusText;
    this.method = method;
    this.endpoint = endpoint;
    this.details = details;
    this.payload = payload;
  }
}

export class ApiClient {
  private static adminToken: string | null = (typeof window !== 'undefined' ? localStorage.getItem('baseball_admin_token') : null);
  private static logs: DatabaseApiLogEntry[] = [];
  private static readonly MAX_LOGS = 250;
  private static logListeners = new Set<(logs: DatabaseApiLogEntry[]) => void>();

  static setAdminToken(token: string | null) {
    this.adminToken = token;
    if (typeof window !== 'undefined') {
      if (token) {
        localStorage.setItem('baseball_admin_token', token);
      } else {
        localStorage.removeItem('baseball_admin_token');
      }
    }
  }

  static getAdminToken(): string | null {
    return this.adminToken;
  }

  /**
   * Register a callback to receive real-time log updates
   */
  static subscribeLogs(listener: (logs: DatabaseApiLogEntry[]) => void): () => void {
    this.logListeners.add(listener);
    listener([...this.logs]);
    return () => {
      this.logListeners.delete(listener);
    };
  }

  static getLogs(): DatabaseApiLogEntry[] {
    return [...this.logs];
  }

  static getWriteLogs(): DatabaseApiLogEntry[] {
    return this.logs.filter((l) => l.isWriteOperation);
  }

  static getFailedWriteLogs(): DatabaseApiLogEntry[] {
    return this.logs.filter((l) => l.isWriteOperation && !l.success);
  }

  static clearLogs(): void {
    this.logs = [];
    this.notifyLogListeners();
  }

  private static notifyLogListeners(): void {
    const snapshot = [...this.logs];
    this.logListeners.forEach((fn) => {
      try {
        fn(snapshot);
      } catch (err) {
        console.error('[ApiLogger] Error in log listener:', err);
      }
    });
  }

  static recordLog(entry: DatabaseApiLogEntry): void {
    this.logs.unshift(entry);
    if (this.logs.length > this.MAX_LOGS) {
      this.logs.pop();
    }
    this.notifyLogListeners();
  }

  static recordCustomLog(entry: {
    method: HttpMethod;
    endpoint: string;
    isWriteOperation: boolean;
    success: boolean;
    status?: number;
    statusText?: string;
    durationMs?: number;
    requestPayload?: any;
    responsePreview?: any;
    error?: { message: string; code?: string | number; details?: any };
    context?: string;
  }): void {
    const id = `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const fullEntry: DatabaseApiLogEntry = {
      id,
      timestamp: new Date().toISOString(),
      epochMs: Date.now(),
      durationMs: entry.durationMs || 0,
      ...entry,
      requestPayload: this.sanitizeForLog(entry.requestPayload),
      responsePreview: this.sanitizeForLog(entry.responsePreview),
    };
    this.recordLog(fullEntry);
  }

  public static sanitizeForLog(data: any): any {
    if (data === null || data === undefined) return data;
    if (typeof data === 'string') {
      if (data.startsWith('adm_') || data.startsWith('eyJh') || (data.length > 60 && !data.startsWith('http') && !data.startsWith('/'))) {
        return '[REDACTED]';
      }
      return data;
    }
    if (typeof data !== 'object') return data;
    if (Array.isArray(data)) return data.map((item) => this.sanitizeForLog(item));

    const sanitized: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      const lower = key.toLowerCase();
      if (
        lower.includes('password') ||
        lower.includes('secret') ||
        lower.includes('token') ||
        lower.includes('auth') ||
        lower.includes('credential') ||
        lower.includes('cookie') ||
        lower.includes('privatekey') ||
        lower.includes('private_key')
      ) {
        sanitized[key] = '[REDACTED]';
      } else if (typeof value === 'object' && value !== null) {
        sanitized[key] = this.sanitizeForLog(value);
      } else {
        sanitized[key] = value;
      }
    }
    return sanitized;
  }

  private static parsePayload(body: any): any {
    if (!body) return undefined;
    if (typeof body === 'string') {
      try {
        return JSON.parse(body);
      } catch {
        return body;
      }
    }
    return body;
  }

  private static cache: Map<string, { timestamp: number; data: any }> = new Map();

  private static getCached<T>(key: string, maxAgeMs = 120000): T | null {
    const entry = this.cache.get(key);
    if (entry && Date.now() - entry.timestamp < maxAgeMs) {
      return entry.data as T;
    }
    try {
      const local = localStorage.getItem(`api_cache_${key}`);
      if (local) {
        const parsed = JSON.parse(local);
        if (parsed && Date.now() - parsed.timestamp < maxAgeMs) {
          this.cache.set(key, parsed);
          return parsed.data as T;
        }
      }
    } catch {
      // Ignore localStorage errors
    }
    return null;
  }

  private static setCached(key: string, data: any): void {
    const entry = { timestamp: Date.now(), data };
    this.cache.set(key, entry);
    try {
      localStorage.setItem(`api_cache_${key}`, JSON.stringify(entry));
    } catch {
      // Ignore quota errors
    }
  }

  public static clearCache(): void {
    this.cache.clear();
    if (typeof window !== 'undefined') {
      try {
        const keysToRemove: string[] = [];
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i);
          if (key && key.startsWith('api_cache_')) {
            keysToRemove.push(key);
          }
        }
        keysToRemove.forEach((k) => localStorage.removeItem(k));
      } catch (err) {
        console.warn('[ApiClient] Could not clear api cache from localStorage', err);
      }
    }
  }

  private static async request<T>(endpoint: string, options?: RequestInit & { context?: string }): Promise<T> {
    const method = ((options?.method || 'GET').toUpperCase()) as HttpMethod;
    const isWrite = method === 'POST' || method === 'PUT' || method === 'DELETE' || method === 'PATCH';
    const requestPayload = this.parsePayload(options?.body);
    const startTime = performance.now();
    const logId = `db_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const contextTag = options?.context ? ` [${options.context}]` : '';

    // Console logging: Start of write operation
    if (isWrite) {
      console.groupCollapsed(
        `%c📝 [DB WRITE START]${contextTag} %c${method} ${endpoint}`,
        'color: #0284c7; font-weight: bold; background: #e0f2fe; padding: 2px 6px; border-radius: 4px;',
        'color: #0f172a; font-weight: 600;'
      );
      console.log('⏰ Timestamp:', new Date().toISOString());
      if (requestPayload !== undefined) {
        console.log('📦 Request Payload:', this.sanitizeForLog(requestPayload));
      }
      console.groupEnd();
    }

    const headers: Record<string, string> = {
      ...(options?.headers as Record<string, string> || {}),
    };

    if (options?.body && !headers['Content-Type']) {
      headers['Content-Type'] = 'application/json';
    }

    if (this.adminToken && !headers['Authorization']) {
      headers['Authorization'] = `Bearer ${this.adminToken}`;
    }

    const maxRetries = isWrite ? 1 : 3;
    let lastNetworkError: any = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const res = await fetch(`${API_BASE}${endpoint}`, {
          credentials: 'include',
          ...options,
          headers,
        });

        const durationMs = Math.round(performance.now() - startTime);

        if (!res.ok) {
          let serverErrorData: any = null;
          let errorMessage = `Error HTTP ${res.status}: ${res.statusText}`;

          try {
            const text = await res.text();
            if (text) {
              try {
                serverErrorData = JSON.parse(text);
                if (serverErrorData.error) {
                  errorMessage = serverErrorData.error;
                } else if (serverErrorData.message) {
                  errorMessage = serverErrorData.message;
                }
              } catch {
                serverErrorData = text;
                errorMessage = text;
              }
            }
          } catch (readErr) {
            console.warn('[ApiLogger] Could not read error response body:', readErr);
          }

          // Expected 401 for session checks does not need loud logs
          const isExpectedAuthCheck = endpoint === '/admin/session' && res.status === 401;

          // Record failed log entry
          const failedEntry: DatabaseApiLogEntry = {
            id: logId,
            timestamp: new Date().toISOString(),
            epochMs: Date.now(),
            method,
            endpoint,
            isWriteOperation: isWrite,
            status: res.status,
            statusText: res.statusText,
            durationMs,
            success: false,
            requestPayload,
            error: {
              message: errorMessage,
              code: res.status,
              details: serverErrorData,
            },
            context: options?.context,
          };
          this.recordLog(failedEntry);

          if (!isExpectedAuthCheck) {
            console.groupCollapsed(
              `%c❌ [DB ${isWrite ? 'WRITE' : 'READ'} FAILED]${contextTag} %c${method} ${endpoint} %c(HTTP ${res.status}: ${errorMessage})`,
              'color: #ffffff; font-weight: bold; background: #dc2626; padding: 2px 6px; border-radius: 4px;',
              'color: #b91c1c; font-weight: bold;',
              'color: #ef4444;'
            );
            console.warn('⚠️ Server Response Message:', errorMessage);
            console.warn('📊 HTTP Status:', `${res.status} ${res.statusText}`);
            console.warn('⏱️ Latency:', `${durationMs}ms`);
            if (isWrite && requestPayload !== undefined) {
              console.warn('📦 Write Payload:', this.sanitizeForLog(requestPayload));
            }
            console.groupEnd();
          }

          throw new DatabaseApiError(
            errorMessage,
            res.status,
            res.statusText,
            method,
            endpoint,
            serverErrorData,
            requestPayload
          );
        }

        // Success response handling
        let data: any = null;
        const text = await res.text();
        if (text) {
          try {
            data = JSON.parse(text);
          } catch {
            data = text;
          }
        }

        // Cache successful read data
        if (!isWrite && data) {
          this.setCached(endpoint, data);
        } else if (isWrite) {
          // Immediately purge cached queries on any write to guarantee UI shows the latest database state
          this.clearCache();
        }

        // Record successful log entry
        const successEntry: DatabaseApiLogEntry = {
          id: logId,
          timestamp: new Date().toISOString(),
          epochMs: Date.now(),
          method,
          endpoint,
          isWriteOperation: isWrite,
          status: res.status,
          statusText: res.statusText,
          durationMs,
          success: true,
          requestPayload,
          responsePreview: typeof data === 'object' ? data : { raw: data },
          context: options?.context,
        };
        this.recordLog(successEntry);

        if (isWrite) {
          console.groupCollapsed(
            `%c✅ [DB WRITE SUCCESS]${contextTag} %c${method} ${endpoint} %c(${durationMs}ms, HTTP ${res.status})`,
            'color: #ffffff; font-weight: bold; background: #16a34a; padding: 2px 6px; border-radius: 4px;',
            'color: #15803d; font-weight: 600;',
            'color: #64748b; font-size: 11px;'
          );
          console.log('⏱️ Duration:', `${durationMs}ms`);
          if (requestPayload !== undefined) {
            console.log('📦 Saved Payload:', this.sanitizeForLog(requestPayload));
          }
          console.log('📬 Response Data:', this.sanitizeForLog(data));
          console.groupEnd();
        }

        return data as T;
      } catch (err: any) {
        if (err instanceof DatabaseApiError) {
          throw err;
        }

        lastNetworkError = err;
        // If it's a network error and we have retries left, wait and retry
        if (attempt < maxRetries) {
          const delayMs = attempt * 300;
          await new Promise((resolve) => setTimeout(resolve, delayMs));
          continue;
        }
      }
    }

    // All retries failed due to network error
    const durationMs = Math.round(performance.now() - startTime);
    const networkErrorMessage = lastNetworkError?.message || 'Error de conexión con el servidor';

    // If it's a GET request and we have cached data, return the cache to prevent UI crash
    if (!isWrite) {
      const cached = this.getCached<T>(endpoint);
      if (cached !== null) {
        console.warn(`[ApiClient] Conexión temporalmente no disponible para ${endpoint}. Usando datos en caché.`);
        return cached;
      }
    }

    const networkFailEntry: DatabaseApiLogEntry = {
      id: logId,
      timestamp: new Date().toISOString(),
      epochMs: Date.now(),
      method,
      endpoint,
      isWriteOperation: isWrite,
      status: 0,
      statusText: 'Network / Client Error',
      durationMs,
      success: false,
      requestPayload,
      error: {
        message: networkErrorMessage,
        code: 'CLIENT_NETWORK_ERROR',
        details: lastNetworkError,
      },
      context: options?.context,
    };
    this.recordLog(networkFailEntry);

    console.warn(
      `[ApiClient] Advertencia de red en ${method} ${endpoint}: ${networkErrorMessage}`
    );

    throw new DatabaseApiError(
      networkErrorMessage,
      0,
      'Network Error',
      method,
      endpoint,
      lastNetworkError,
      requestPayload
    );
  }

  // Competitions
  static getCompetitions(): Promise<Competition[]> {
    return this.request<Competition[]>('/competitions');
  }

  static getSeasons(competitionId?: string): Promise<Season[]> {
    const q = competitionId ? `?competition=${encodeURIComponent(competitionId)}` : '';
    return this.request<Season[]>(`/seasons${q}`);
  }

  // Teams
  static async getTeams(competitionId?: string): Promise<Team[]> {
    const q = competitionId ? `?competition=${encodeURIComponent(competitionId)}` : '';
    const teams = await this.request<Team[]>(`/teams${q}`);
    const merged = clientPersistence.mergeTeamsWithCustomData(teams);
    clientPersistence.syncWithServer().catch(() => {});
    return merged;
  }

  static async getTeamDetail(id: string): Promise<{ team: Team; roster: Player[]; games: Game[] }> {
    const res = await this.request<{ team: Team; roster: Player[]; games: Game[] }>(`/teams/${id}`);
    const logoData = clientPersistence.getTeamLogoData(res.team.id) || clientPersistence.getTeamLogoData(res.team.shortName);
    if (logoData) {
      res.team.logo = logoData.logo;
      if (logoData.primaryColor) {
        if (!res.team.colors) res.team.colors = { primary: logoData.primaryColor, secondary: '#FFFFFF', text: '#FFFFFF' };
        else res.team.colors.primary = logoData.primaryColor;
      }
    }
    return res;
  }

  static async getTeamComparison(teamA: string, teamB: string): Promise<TeamDirectComparisonData> {
    const res = await this.request<TeamDirectComparisonData>(
      `/teams/compare?teamA=${encodeURIComponent(teamA)}&teamB=${encodeURIComponent(teamB)}`
    );
    // Apply client persistence logos and colors if available
    const logoA = clientPersistence.getTeamLogoData(res.teamA.id) || clientPersistence.getTeamLogoData(res.teamA.shortName);
    if (logoA) {
      res.teamA.logo = logoA.logo;
      if (logoA.primaryColor) {
        if (!res.teamA.colors) res.teamA.colors = { primary: logoA.primaryColor, secondary: '#FFFFFF', text: '#FFFFFF' };
        else res.teamA.colors.primary = logoA.primaryColor;
      }
    }
    const logoB = clientPersistence.getTeamLogoData(res.teamB.id) || clientPersistence.getTeamLogoData(res.teamB.shortName);
    if (logoB) {
      res.teamB.logo = logoB.logo;
      if (logoB.primaryColor) {
        if (!res.teamB.colors) res.teamB.colors = { primary: logoB.primaryColor, secondary: '#FFFFFF', text: '#FFFFFF' };
        else res.teamB.colors.primary = logoB.primaryColor;
      }
    }
    return res;
  }

  static async updateTeamLogo(id: string, logo: string, primaryColor?: string): Promise<{ success: boolean; message: string; team: Team; logo: string }> {
    // 1. Immediately cache in client persistence so it can never be lost
    clientPersistence.saveTeamLogo(id, logo, primaryColor);
    this.clearCache();

    // 2. Persist to server database
    const res = await this.request<{ success: boolean; message: string; team: Team; logo: string }>(`/teams/${id}/logo`, {
      method: 'PUT',
      body: JSON.stringify({ logo, primaryColor }),
    });

    // 3. Keep client persistence in sync with response
    if (res?.team) {
      clientPersistence.saveTeamLogo(res.team.id, res.team.logo, primaryColor);
      clientPersistence.saveTeamLogo(res.team.shortName, res.team.logo, primaryColor);
    }
    this.clearCache();
    return res;
  }

  // Players
  static async getPlayers(params?: {
    teamId?: string;
    position?: string;
    search?: string;
    page?: number;
    limit?: number;
  }): Promise<{ items: Player[]; total: number }> {
    const searchParams = new URLSearchParams();
    if (params?.teamId) searchParams.set('teamId', params.teamId);
    if (params?.position) searchParams.set('position', params.position);
    if (params?.search) searchParams.set('search', params.search);
    if (params?.page) searchParams.set('page', params.page.toString());
    if (params?.limit) searchParams.set('limit', params.limit.toString());

    const res = await this.request<{ items: Player[]; total: number }>(`/players?${searchParams.toString()}`);
    // Merge with client-side persistent custom players
    let mergedItems = clientPersistence.mergePlayersWithCustomData(res.items);
    if (params?.teamId) {
      const targetTeamId = params.teamId;
      const lowerTeamId = targetTeamId.toLowerCase();
      mergedItems = mergedItems.filter((p) => p.teamId === targetTeamId || p.teamShort.toLowerCase() === lowerTeamId);
    }
    if (params?.position && params.position !== 'ALL') {
      mergedItems = mergedItems.filter((p) => p.position === params.position);
    }
    if (params?.search) {
      const q = params.search.toLowerCase();
      mergedItems = mergedItems.filter((p) => p.fullName.toLowerCase().includes(q) || p.slug.toLowerCase().includes(q));
    }
    return {
      items: mergedItems,
      total: Math.max(res.total, mergedItems.length),
    };
  }

  static getPlayerDetail(id: string): Promise<PlayerDetailResponse> {
    return this.request<PlayerDetailResponse>(`/players/${id}`);
  }

  static getPlayerByTeamAndSlug(teamSlugOrId: string, playerSlugOrId: string): Promise<PlayerDetailResponse> {
    return this.request<PlayerDetailResponse>(`/teams/${encodeURIComponent(teamSlugOrId)}/players/${encodeURIComponent(playerSlugOrId)}`);
  }

  static getPlayerRecentGames(id: string, limit = 10): Promise<PlayerGameLogItem[]> {
    return this.request<PlayerGameLogItem[]>(`/players/${id}/recent-games?limit=${limit}`);
  }

  static savePlayerSeasonBatting(playerId: string, stat: Partial<BattingStats>): Promise<{ success: boolean; stat: BattingStats; historical: any }> {
    return this.request<{ success: boolean; stat: BattingStats; historical: any }>(`/players/${playerId}/stats/batting`, {
      method: 'POST',
      body: JSON.stringify(stat),
    });
  }

  static savePlayerSeasonPitching(playerId: string, stat: Partial<PitchingStats>): Promise<{ success: boolean; stat: PitchingStats; historical: any }> {
    return this.request<{ success: boolean; stat: PitchingStats; historical: any }>(`/players/${playerId}/stats/pitching`, {
      method: 'POST',
      body: JSON.stringify(stat),
    });
  }

  static deletePlayerSeasonStat(playerId: string, statId: string, type: 'batting' | 'pitching'): Promise<{ success: boolean; historical: any }> {
    return this.request<{ success: boolean; historical: any }>(`/players/${playerId}/stats/${statId}?type=${type}`, {
      method: 'DELETE',
    });
  }

  static updatePlayerPhoto(id: string, photo: string): Promise<{ success: boolean; message: string; player: Player; photo: string }> {
    return this.request<{ success: boolean; message: string; player: Player; photo: string }>(`/players/${id}/photo`, {
      method: 'PUT',
      body: JSON.stringify({ photo }),
    });
  }

  // Games
  static getGames(params?: {
    competition?: string;
    season?: string;
    status?: string;
    team?: string;
    sort?: 'asc' | 'desc';
    order?: 'asc' | 'desc';
  }): Promise<Game[]> {
    const searchParams = new URLSearchParams();
    if (params?.competition) searchParams.set('competition', params.competition);
    if (params?.season) searchParams.set('season', params.season);
    if (params?.status) searchParams.set('status', params.status);
    if (params?.team) searchParams.set('team', params.team);
    if (params?.sort) searchParams.set('sort', params.sort);
    if (params?.order) searchParams.set('order', params.order);

    return this.request<Game[]>(`/games?${searchParams.toString()}`);
  }

  static getGameDetail(id: string): Promise<Game> {
    return this.request<Game>(`/games/${id}`);
  }

  static getMatchupComparison(id: string): Promise<MatchupComparisonData> {
    return this.request<MatchupComparisonData>(`/games/${id}/matchup`);
  }

  static compareTeams(teamA: string, teamB: string): Promise<TeamDirectComparisonData> {
    return this.request<TeamDirectComparisonData>(`/teams/compare?teamA=${encodeURIComponent(teamA)}&teamB=${encodeURIComponent(teamB)}`);
  }

  static simulateGameRun(params?: { gameId?: string; side?: 'home' | 'away'; runs?: number }): Promise<{
    game: Game;
    runsScored: number;
    scoringTeam: Team;
    scoringSide: 'home' | 'away';
    title: string;
    playDescription: string;
    playType: 'homerun' | 'hit' | 'sacrifice' | 'walk' | 'standard';
  }> {
    return this.request('/games/simulate-run', {
      method: 'POST',
      body: JSON.stringify(params || {}),
    });
  }

  // Standings
  static getStandings(params?: { competition?: string; division?: string; season?: string; seasonId?: string }): Promise<Standing[]> {
    const searchParams = new URLSearchParams();
    if (params?.competition) searchParams.set('competition', params.competition);
    if (params?.division) searchParams.set('division', params.division);
    if (params?.season) searchParams.set('season', params.season);
    if (params?.seasonId) searchParams.set('seasonId', params.seasonId);

    return this.request<Standing[]>(`/standings?${searchParams.toString()}`);
  }

  // Stats
  static getStats<T = BattingStats[] | PitchingStats[]>(params?: {
    type?: 'batting' | 'pitching' | 'advanced';
    sortBy?: string;
    order?: 'asc' | 'desc';
    season?: string;
    seasonId?: string;
  }): Promise<T> {
    const searchParams = new URLSearchParams();
    if (params?.type) searchParams.set('type', params.type);
    if (params?.sortBy) searchParams.set('sortBy', params.sortBy);
    if (params?.order) searchParams.set('order', params.order);
    if (params?.season) searchParams.set('season', params.season);
    if (params?.seasonId) searchParams.set('seasonId', params.seasonId);

    return this.request<T>(`/stats?${searchParams.toString()}`);
  }

  // Leaders
  static getLeaders(params: { category: 'batting' | 'pitching'; stat: string; limit?: number; season?: string; seasonId?: string }): Promise<any[]> {
    const searchParams = new URLSearchParams({
      category: params.category,
      stat: params.stat,
      limit: (params.limit || 5).toString(),
    });
    if (params.season) searchParams.set('season', params.season);
    if (params.seasonId) searchParams.set('seasonId', params.seasonId);

    return this.request<any[]>(`/leaders?${searchParams.toString()}`);
  }

  // News
  static getNews(params?: { limit?: number; category?: string }): Promise<NewsArticle[]> {
    const searchParams = new URLSearchParams();
    if (params?.limit) searchParams.set('limit', params.limit.toString());
    if (params?.category) searchParams.set('category', params.category);

    return this.request<NewsArticle[]>(`/news?${searchParams.toString()}`);
  }

  static getNewsArticle(slug: string): Promise<NewsArticle> {
    return this.request<NewsArticle>(`/news/${slug}`);
  }

  // Article Comments (Community interactions for public consumers)
  static getArticleComments(slug: string): Promise<ArticleComment[]> {
    return this.request<ArticleComment[]>(`/news/${encodeURIComponent(slug)}/comments`);
  }

  static addArticleComment(
    slug: string,
    payload: { authorName?: string; favoriteTeam?: string; content: string }
  ): Promise<ArticleComment> {
    return this.request<ArticleComment>(`/news/${encodeURIComponent(slug)}/comments`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  static deleteArticleComment(commentId: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/news/comments/${commentId}`, {
      method: 'DELETE',
    });
  }

  static likeArticleComment(commentId: string): Promise<{ success: boolean; likes: number }> {
    return this.request<{ success: boolean; likes: number }>(`/news/comments/${commentId}/like`, {
      method: 'POST',
    });
  }

  // Videos
  static getVideos(): Promise<VideoItem[]> {
    return this.request<VideoItem[]>('/videos');
  }

  // Global Search
  static search(query: string): Promise<{
    players: Player[];
    teams: Team[];
    articles?: NewsArticle[];
    news?: NewsArticle[];
    competitions: Competition[];
  }> {
    return this.request<{
      players: Player[];
      teams: Team[];
      articles?: NewsArticle[];
      news?: NewsArticle[];
      competitions: Competition[];
    }>(`/search?q=${encodeURIComponent(query)}`);
  }

  // Ingestion validation & commit
  static validateIngestion(rawText: string, format: 'csv' | 'json'): Promise<IngestionValidationSummary> {
    return this.request<IngestionValidationSummary>('/ingest/validate', {
      method: 'POST',
      body: JSON.stringify({ rawText, format }),
    });
  }

  static commitIngestion(records: any[]): Promise<{ success: boolean; count: number; message: string }> {
    return this.request<{ success: boolean; count: number; message: string }>('/ingest/commit', {
      method: 'POST',
      body: JSON.stringify({ records }),
    });
  }

  // Real-Time Notifications, Webhooks & Polling
  static getNotificationsHistory(limit = 20): Promise<ScoreNotificationEvent[]> {
    return this.request<ScoreNotificationEvent[]>(`/notifications/history?limit=${limit}`);
  }

  static pollScoreNotifications(
    since?: number,
    limit = 20
  ): Promise<{
    events: ScoreNotificationEvent[];
    timestamp: number;
    activeClients: number;
    liveGamesCount: number;
  }> {
    const q = since ? `?since=${since}&limit=${limit}` : `?limit=${limit}`;
    return this.request(`/notifications/poll${q}`);
  }

  static sendScoreWebhook(payload: {
    gameId: string;
    scoringTeamSide?: 'home' | 'away';
    runs?: number;
    playDescription?: string;
    title?: string;
    playType?: string;
  }): Promise<{ success: boolean; event?: ScoreNotificationEvent; message: string }> {
    return this.request('/webhooks/score-update', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  static testScoreNotification(): Promise<{
    success: boolean;
    message: string;
    event: ScoreNotificationEvent;
  }> {
    return this.request('/notifications/test', {
      method: 'POST',
    });
  }

  static createScoreEventSource(): EventSource | null {
    if (typeof window === 'undefined' || !('EventSource' in window)) {
      return null;
    }
    return new EventSource(`${API_BASE}/events/score-changes`);
  }

  // ===================================
  // ADMIN AUTH & MANAGEMENT API METHODS
  // ===================================

  static async adminLogin(username: string, password: string): Promise<AdminAuthResponse> {
    const res = await this.request<AdminAuthResponse>('/admin/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    });
    if (res.success && res.token) {
      this.setAdminToken(res.token);
    }
    return res;
  }

  static async checkAdminSession(): Promise<{ valid: boolean; admin?: AdminUser }> {
    try {
      const res = await this.request<{ valid: boolean; admin?: AdminUser }>('/admin/session');
      return res;
    } catch {
      this.setAdminToken(null);
      return { valid: false };
    }
  }

  static async adminLogout(): Promise<{ success: boolean }> {
    try {
      const res = await this.request<{ success: boolean }>('/admin/logout', {
        method: 'POST',
      });
      return res;
    } finally {
      this.setAdminToken(null);
    }
  }

  static getAdminOverview(): Promise<AdminSystemOverview> {
    return this.request<AdminSystemOverview>('/admin/overview');
  }

  static getAdminAuditLogs(limit = 50): Promise<AdminAuditLog[]> {
    return this.request<AdminAuditLog[]>(`/admin/audit-logs?limit=${limit}`);
  }

  static createAdminGame(gameData: Partial<Game>): Promise<Game> {
    return this.request<Game>('/admin/games', {
      method: 'POST',
      body: JSON.stringify(gameData),
    });
  }

  static createAdminGameSeries(seriesData: {
    awayTeamId: string;
    homeTeamId: string;
    startDate: string;
    startTime?: string;
    numberOfGames: number;
    stadium?: string;
  }): Promise<Game[]> {
    return this.request<Game[]>('/admin/games/series', {
      method: 'POST',
      body: JSON.stringify(seriesData),
    });
  }

  static updateAdminGame(id: string, updates: Partial<Game>): Promise<Game> {
    return this.request<Game>(`/admin/games/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  static deleteAdminGame(id: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/admin/games/${id}`, {
      method: 'DELETE',
    });
  }

  static async createAdminPlayer(playerData: Partial<Player>): Promise<Player> {
    const res = await this.request<Player>('/admin/players', {
      method: 'POST',
      body: JSON.stringify(playerData),
    });
    if (res) {
      clientPersistence.savePlayer(res);
    }
    this.clearCache();
    return res;
  }

  static async updateAdminPlayer(id: string, updates: Partial<Player>): Promise<Player> {
    const res = await this.request<Player>(`/admin/players/${encodeURIComponent(id)}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
    if (res) {
      clientPersistence.savePlayer(res);
    }
    this.clearCache();
    return res;
  }

  static async updatePlayer(id: string, updates: Partial<Player>): Promise<Player> {
    return this.updateAdminPlayer(id, updates);
  }

  static async deleteAdminPlayer(id: string): Promise<{ success: boolean; message: string }> {
    clientPersistence.recordDeletedPlayer(id);
    this.clearCache();
    return this.request<{ success: boolean; message: string }>(`/admin/players/${id}`, {
      method: 'DELETE',
    });
  }

  static async bulkDeleteAdminPlayers(ids: string[]): Promise<{
    success: boolean;
    deletedCount: number;
    deletedIds: string[];
    message: string;
  }> {
    for (const id of ids) {
      clientPersistence.recordDeletedPlayer(id);
    }
    this.clearCache();
    return this.request('/admin/players/bulk-delete', {
      method: 'POST',
      body: JSON.stringify({ ids }),
    });
  }

  static bulkUpdateAdminPlayers(ids: string[], updates: Partial<Player>): Promise<{
    success: boolean;
    updatedCount: number;
    updatedPlayers: Player[];
    message: string;
  }> {
    return this.request('/admin/players/bulk-update', {
      method: 'POST',
      body: JSON.stringify({ ids, updates }),
    });
  }

  static async createAdminTeam(teamData: Partial<Team>): Promise<Team> {
    const res = await this.request<Team>('/teams', {
      method: 'POST',
      body: JSON.stringify(teamData),
    });
    if (res) {
      clientPersistence.saveTeam(res);
    }
    this.clearCache();
    return res;
  }

  static async updateAdminTeam(id: string, updates: Partial<Team>): Promise<Team> {
    const res = await this.request<Team>(`/teams/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
    if (res) {
      clientPersistence.saveTeam(res);
    }
    this.clearCache();
    return res;
  }

  static async deleteAdminTeam(id: string): Promise<{ success: boolean; message: string; deletedTeam?: Team }> {
    clientPersistence.recordDeletedTeam(id);
    this.clearCache();
    return this.request<{ success: boolean; message: string; deletedTeam?: Team }>(`/teams/${id}`, {
      method: 'DELETE',
    });
  }

  static seedAll16Teams(): Promise<{ success: boolean; message: string; teams: Team[] }> {
    return this.request<{ success: boolean; message: string; teams: Team[] }>('/teams/seed-16', {
      method: 'POST',
    });
  }

  static importAdminPlayers(players: any[]): Promise<{
    success: boolean;
    importedCount: number;
    createdCount: number;
    updatedCount: number;
    message: string;
    players: Player[];
  }> {
    return this.request('/admin/players/import', {
      method: 'POST',
      body: JSON.stringify({ players }),
    });
  }

  static importAdminHistoricalStats(statsData: any): Promise<{
    success: boolean;
    importedCount: number;
    battingCount: number;
    pitchingCount: number;
    playersCount: number;
    unmatchedCount: number;
    unmatchedEntries: any[];
    affectedPlayerIds: string[];
    message: string;
    details: any[];
  }> {
    this.clearCache();
    return this.request('/admin/stats/import', {
      method: 'POST',
      body: JSON.stringify(statsData),
    });
  }

  static importPlayerHistoricalStats(playerId: string, statsData: any): Promise<{
    success: boolean;
    importedCount: number;
    battingCount: number;
    pitchingCount: number;
    historical: any;
    message: string;
  }> {
    this.clearCache();
    return this.request(`/players/${encodeURIComponent(playerId)}/stats/import`, {
      method: 'POST',
      body: JSON.stringify(statsData),
    });
  }

  static createAdminNews(newsData: Partial<NewsArticle>): Promise<NewsArticle> {
    return this.request<NewsArticle>('/admin/news', {
      method: 'POST',
      body: JSON.stringify(newsData),
    });
  }

  static updateAdminNews(id: string, updates: Partial<NewsArticle>): Promise<NewsArticle> {
    return this.request<NewsArticle>(`/admin/news/${id}`, {
      method: 'PUT',
      body: JSON.stringify(updates),
    });
  }

  static deleteAdminNews(id: string): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>(`/admin/news/${id}`, {
      method: 'DELETE',
    });
  }

  static resetAdminDemo(): Promise<{ success: boolean; message: string }> {
    return this.request<{ success: boolean; message: string }>('/admin/system/reset-demo', {
      method: 'POST',
    });
  }

  static getDatabaseStatus(): Promise<{
    success: boolean;
    status: string;
    filePath: string;
    exists: boolean;
    sizeBytes: number;
    lastModified?: string;
    counts: Record<string, number>;
  }> {
    return this.request('/admin/system/database-status');
  }

  static forcePersistDatabase(): Promise<{
    success: boolean;
    message: string;
    info: any;
  }> {
    return this.request('/admin/system/persist', {
      method: 'POST',
    });
  }

  static exportDatabaseBackup(): Promise<any> {
    return this.request('/admin/system/backup');
  }

  static restoreDatabaseBackup(backupData: any): Promise<{
    success: boolean;
    message: string;
    counts: Record<string, number>;
  }> {
    return this.request('/admin/system/restore', {
      method: 'POST',
      body: JSON.stringify(backupData),
    });
  }

  static syncClientBackup(data: { players?: Player[]; teams?: Team[] }): Promise<{
    success: boolean;
    message: string;
    counts: Record<string, number>;
  }> {
    return this.request('/admin/system/sync-client', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }
}
